﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyEmail_WPF
{
    class AddToCommand : ICommand
    {
        private int RecipientList_index = 0;
        public string Name
        {
            get
            {
                return "AddTo";
            }
        }

        public string Execute(string[] parameters, State state)
        {
            throw new NotImplementedException();
        }

        public string Execute(string parameters, State state)
        {
            if (parameters == "")
            {
                RecipientList_index = 0;
                for(int j=0;j<200;j++)//clearing the RecipientList
                    state.RecipientList[j] = null;
            }
           

            if(state.RecipientList == null)
            state.RecipientList = new string[200];

            state.RecipientList[RecipientList_index++] = parameters;
          
            return $"To updated to '{parameters}'";
        }

        

    }
}
