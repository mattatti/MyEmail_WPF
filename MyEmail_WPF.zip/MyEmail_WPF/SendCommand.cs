﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyEmail_WPF
{
    class SendCommand : ICommand
    {
        private EmailClient emailClient;
      

        public SendCommand(string gmailAccount, string password)
        {
            emailClient = new EmailClient(gmailAccount, password);
        }

        public string Name
        {
            get
            {
                return "send";
            }
        }

        public string Execute(string parameters, State state)
        {
            if (IsRecipientListEmpty(state))
                return "Error: no recipients specified";
            if (state.Subject == null || state.Body == null)
                return "Error: missing subject or body";
            foreach (string address in state.RecipientList)
                if (address != null)
                    emailClient.Send(address, state.Subject, state.Body);
            return $"Sent {state.Body} to {state.RecipientList.Length} recipients";
        }

        public string Execute(string[] parameters, State state)
        {
            return Execute("placeholder", state);
        }

        private bool IsRecipientListEmpty(State state)
        {
            if (state.RecipientList == null)
                return true;
            foreach (string recipient in state.RecipientList)
                if (!String.IsNullOrWhiteSpace(recipient))
                    return false;
            return true;
        }
    }
}
