﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyEmail_WPF
{
    class BodyCommand : ICommand
    {
        public string Name
        {
            get
            {
                return "body";
            }
        }

        public string Execute(string parameters, State state)
        {
            if (parameters == null || parameters == "")
                return "Wrong number of parameters: Command 'body' requires 1 parameter";
            state.Body = parameters;
            state.Body = state.Body.Replace("\n", "\r\n");
            return $"Body updated to '{parameters}'";
        }

        public string Execute(string[] parameters, State state)
        {
            return Execute(string.Join(" ", parameters), state);
        }
    }
}
