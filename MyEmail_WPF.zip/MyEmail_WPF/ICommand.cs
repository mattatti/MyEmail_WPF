﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyEmail_WPF
{
    interface ICommand
    {
        string Name { get; }

        string Execute(string parameters, State state);

        string Execute(string[] parameters, State state);
    }
}
