﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MyEmail_WPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>

    public partial class MainWindow : Window
    {
        private const int numberOfCommandTypes = 5;
        private const int subjectCommandIndex = 0;
        private const int bodyCommandIndex = 1;
        private const int toCommandIndex = 2;
        private const int sendCommandIndex = 3;
        private const int AddToCommandIndex = 4;
        
        private readonly ICommand[] commands;
        private readonly State state;
        public MainWindow()
        {
            InitializeComponent();
            
            commands = new ICommand[numberOfCommandTypes];
            commands[subjectCommandIndex] = new SubjectCommand();
            commands[bodyCommandIndex] = new BodyCommand();
            commands[toCommandIndex] = new ToCommand();
            commands[sendCommandIndex] = new SendCommand("username@gmail.com", "password");//Insert your Gmail account details here.
            commands[AddToCommandIndex] = new AddToCommand();

            state = new State();  
    }

        private void send_Click(object sender, RoutedEventArgs e)
        {
            commands[subjectCommandIndex].Execute(addsubject.Text, state);
            commands[bodyCommandIndex].Execute(addbody.Text,state);
            commands[sendCommandIndex].Execute(" ", state); 
        }
        private void add_Click(object sender, RoutedEventArgs e)
        {    
            commands[AddToCommandIndex].Execute(addemail.Text, state);
            addrecipients.Text += addemail.Text + '\n';
            addemail.Clear();
        }

        private void clear_Click(object sender, RoutedEventArgs e)
        {
            addsubject.Clear();
            addrecipients.Clear();
            commands[AddToCommandIndex].Execute("", state);
            addemail.Clear();
            addbody.Clear();
        }

        private void addrecipients_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
