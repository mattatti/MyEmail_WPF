﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyEmail_WPF
{
    class SubjectCommand : ICommand
    {
        public string Name
        {
            get
            {
                return "subject";
            }
        }

        public string Execute(string parameters, State state)
        {
            if (String.IsNullOrWhiteSpace(parameters))
                return "Wrong number of parameters: Command 'subject' requires 1 parameter";
            state.Subject = parameters;
            return $"Subject updated to '{parameters}'";
        }

        public string Execute(string[] parameters, State state)
        {
            return Execute(string.Join(" ", parameters), state);
        }
    }
}
